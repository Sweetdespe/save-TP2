package boutique.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import boutique.models.Cart;
import boutique.models.CartDao;
import boutique.models.ProductDao;
import boutique.models.User;
import boutique.models.UserDao;
import boutique.utils.Custom;
import boutique.utils.Utils;
import boutique.models.Product;
import boutique.models.ProductDao;

/**
 * Class CartController
 */
@Controller
@CrossOrigin(origins="*", methods= {RequestMethod.GET, RequestMethod.POST, RequestMethod.DELETE, RequestMethod.PUT})
public class CartController {

	// ------------------------
	// PUBLIC METHODS
	// ------------------------

	

	
	/**
	 * Create a new cart 
	 */
	@RequestMapping(value = "/carts/add", method=RequestMethod.POST)
	@ResponseBody
	public String create(
			@RequestParam(value="apikey") String p_apikey, 
			@RequestParam(value="user_id") Long p_userid
	) {
		try 
		{
			User current = userDao.getByApiKey(p_apikey);
			User owner = userDao.getById(p_userid);
			
			// si on est admin ou l'utilisateur concerné
			if( 
					current != null && 
					current.isAdmin() || ( current.getId() == owner.getId() ) 
			) {
				
				// on cherche si l'utilisateur possède encore un panier non clôturé
				// ( correspondant à une ancienne commande )
				// si l'utilisateur ne possède pas un panier actif
				if( cartDao.getNumOpenedCartByUserId(owner.getId()) == 0) {
					Cart cart = new Cart(owner);
					cartDao.create(cart);
				}
				
			}
			else {
				return Custom.getJsonError(Custom.BAD_ROLE_ERROR);
			}
		} 
		catch (Exception ex) 
		{
			System.out.println(ex.getMessage());
			return Custom.getJsonError(Custom.CREATE_ERROR);
		}
		
		return Custom.getJsonSuccess();
	}

	/**
	 * Delete the cart
	 */
	@RequestMapping(value = "/carts/remove", method=RequestMethod.DELETE)
	@ResponseBody
	public String delete(
			@RequestParam(value="cart_id") long p_cartid, 
			@RequestParam(value="apikey") String p_apikey
	) {
		try {
			
			User current = userDao.getByApiKey(p_apikey);
			
			if( current != null && current.isAdmin() ) {
				Cart cart = cartDao.getById(p_cartid);
				cartDao.delete(cart);
			}
			else {
				return Custom.getJsonError(Custom.BAD_ROLE_ERROR);
			}
			
			
		} catch (Exception ex) {
			return Custom.getJsonError(Custom.DELETE_ERROR);
		}
		
		return Custom.getJsonSuccess();
	}

	/**
	 * Retrieve all carts
	 */
	@RequestMapping(value = "/carts", method=RequestMethod.GET)
	@ResponseBody

	public String getAll( 
			@RequestParam(value="apikey") String p_apikey 
	) {
		try {
			User current = userDao.getByApiKey(p_apikey);
			
			if( current != null && current.isAdmin() )
				return cartDao.getAll().toString();
			else
				return Custom.getJsonError(Custom.BAD_ROLE_ERROR);
			
		} catch (Exception ex) {
			return Custom.getJsonError(Custom.READ_ERROR);
		}
	}
	
	/**
	 * Retrieve a cart by id
	 */
	@RequestMapping(value = "/get-cart-by-id", method=RequestMethod.GET)
	@ResponseBody

	public String getById( 
			@RequestParam(value="apikey") String p_apikey, 
			@RequestParam(value="cart_id") Long p_cartid
	) {
		try {
			User current = userDao.getByApiKey(p_apikey);
			Cart cart    = cartDao.getById(p_cartid);
			
			
			
			if( 
					current 		!= null &&  // si l'utilisateur correspondant à l'apikey existe 
					cart 			!= null	&&  // ainsi que le panier
					cart.getOwner() != null &&  // que le panier est possédé par quelqu'un
					(
							current.isAdmin()	// que l'utilisateur courant est admin 
								|| 				// ou 
							cart.getOwner().getId() == current.getId() // si le panier lui appartient 
					)
			) {
				// on retourne le panier
				return cart.toString();
			}
			else {
				return Custom.getJsonError(Custom.BAD_ROLE_ERROR);
			}
			
		} catch (Exception ex) {
			return Custom.getJsonError(Custom.READ_ERROR);
		}
	}

	/**
	 * Update the cart
	 */
	@RequestMapping(value = "/carts/add-product", method=RequestMethod.PUT)
	@ResponseBody
	public String addProductToCart(
			@RequestParam(value="apikey") String p_apikey, 
			@RequestParam(value="product_id") Long p_productid,
			@RequestParam(value="cart_id") Long p_cartid
	) {
		try {
			
			User current 	= userDao.getByApiKey(p_apikey);
			Cart cart 		= cartDao.getById(p_cartid);
			Product product = productDao.getById(p_productid);
			
						
			if( 
					current 		!= null &&  // si l'utilisateur correspondant à l'apikey existe 
					product 		!= null	&&  // ainsi que le produit .. 
					cart 			!= null	&&  // et le panier 
					cart.getOwner() != null &&  // que le panier est possédé par quelqu'un
					(
							current.isAdmin()	// que l'utilisateur courant est admin 
								|| 				// ou 
							cart.getOwner().getId() == current.getId() // si le panier lui appartient 
					)
			) {
				// on ajoute le produit au panier
				cart.getProducts().add(product);
				cartDao.update(cart);
			}
			else {
				return Custom.getJsonError(Custom.BAD_ROLE_ERROR);
			}
			
			
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return Custom.getJsonError(Custom.UPDATE_ERROR);
		}
		
		return Custom.getJsonSuccess();
	}
	
	
	/**
	 * Update the cart
	 */
	@RequestMapping(value = "/carts/remove-product", method=RequestMethod.PUT)
	@ResponseBody
	public String removeProductFromCart(
			@RequestParam(value="apikey") String p_apikey, 
			@RequestParam(value="product_id") Long p_productid,
			@RequestParam(value="cart_id") Long p_cartid
	) {
		try {
			
			User current 	= userDao.getByApiKey(p_apikey);
			Cart cart 		= cartDao.getById(p_cartid);
			Product product = productDao.getById(p_productid);
						
			if( 
					current 		!= null &&  // si l'utilisateur correspondant à l'apikey existe 
					product 		!= null	&&  // ainsi que le produit .. 
					cart 			!= null	&&  // et le panier 
					cart.getOwner() != null &&  // que le panier est possédé par quelqu'un
					(
							current.isAdmin()	// que l'utilisateur courant est admin 
								|| 				// ou 
							cart.getOwner().getId() == current.getId() // si le panier lui appartient 
					)
			) {
				// on retire le produit du panier
				cart.getProducts().remove(product);
				cartDao.update(cart);
			}
			else {
				return Custom.getJsonError(Custom.BAD_ROLE_ERROR);
			}
			
			
		} catch (Exception ex) {
			return Custom.getJsonError(Custom.UPDATE_ERROR);
		}
		
		return Custom.getJsonSuccess();
	}

	// ------------------------
	// PRIVATE FIELDS
	// ------------------------

	@Autowired
	private UserDao userDao;
	
	@Autowired
	private CartDao cartDao;
	
	@Autowired
	private ProductDao productDao;

} // class CartController
