package boutique.utils;

public class Custom {
	static final public int MYSQL_ERROR 	= 1000;
	static final public int DELETE_ERROR 	= 1100;
	static final public int CREATE_ERROR 	= 1200;
	static final public int UPDATE_ERROR 	= 1300;
	static final public int READ_ERROR 		= 1400;
	static final public int BAD_ROLE_ERROR 	= 1500;
	static final public int UNKNOWN_ERROR 	= 1600;
	static final public int AUTH_ERROR 		= 1700;

	static public String[] Error_message = {"mySQL error",
			"Delete error",
			"Create error",
			"Update  error",
			"Read error",
			"Bad Role error",
			"Unknown error",
			"Authentification error"};


	public final static String getJsonError( int p_error) {

		switch ( p_error ) {

		case MYSQL_ERROR:
		case DELETE_ERROR:
		case CREATE_ERROR:
		case UPDATE_ERROR:
		case READ_ERROR:
		case BAD_ROLE_ERROR:
		case AUTH_ERROR:
				return "{\""+Error_message[(p_error-1000)/100]+"\": \"error\", \"code\": "+p_error+"}";

		default :
			return "{\"Unknown error\": \"error\", \"code\": "+UNKNOWN_ERROR+"}";
		}
	}
	
	public final static String getJsonSuccess() {
		return "{\"message\":\"ok\"}";
	}


}