package boutique.utils;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;

public class Utils {

	public Utils() {}
	
	public static String newApiKey() {
		
		// taille d'une chaine de caratere entre 5 et 10 CHAR 
		int length = 5 + ((int)(Math.random() * 10));
		
		// Chaine de caratere pouvant etre modifier a volonté dans le source
	    String chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
	    String pass = "";
	    for(int x=0;x<length;x++)
	    {
	       int i = (int)Math.floor(Math.random() * chars.length());
	       pass += chars.charAt(i);
	    }
		
	    //Ajout d'une string basé sur un "int" aléatoire
		String current = pass + ((int)(Math.random() * System.currentTimeMillis()));
		
		//return current;
		return Utils.encrypt(current);
	}
	
	
	public static String encrypt(String p_value) {
		
		try {
			//ajout d'un "salt" : pomme_
			p_value= "pomme_" + p_value;

			MessageDigest md = MessageDigest.getInstance("SHA-1");
			md.reset();
			byte[] encoded = md.digest( p_value.getBytes("UTF-8") );
			return byteToHex(encoded);
			
		} catch (NoSuchAlgorithmException | UnsupportedEncodingException  e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}
	
	private static String byteToHex(final byte[] hash)
	{
	    Formatter formatter = new Formatter();
	    for (byte b : hash)
	    {
	        formatter.format("%02x", b);
	    }
	    String result = formatter.toString();
	    formatter.close();
	    return result;
	}

}
