export const environment = {
  production: true,

  getCatalogUrl:"http://localhost:8080/products",
  postCatalogUrl:"http://localhost:8080/products/add",
  delCatalogUrl:"http://localhost:8080/products/remove",
  updateCatalogUrl:"http://localhost:8080/products/update",
  
  getCartUrl:"http://localhost:8080/mycart",
  postCartUrl:"http://localhost:8080/mycart/add",
  delCartUrl:"http://localhost:8080/mycart/remove",
  updateCartUrl:"http://localhost:8080/mycart/update",

  getUsersUrl:"http://localhost:8080/users",
  authUrl: "http://localhost:8080/users/auth",
  addUserUrl: "http://localhost:8080/users/get-by-id",
  updateUsers: "http://localhost:8080/users/update",
  getUsersbyID: "http://localhost:8080/users/add",
  delUserUrl: "http://localhost:8080/users/remove"

};
