import { Component, OnInit } from '@angular/core';
import { UserService } from '../service/user.service';
import { User } from '../bean/User';

@Component({
  selector: 'app-userinfo',
  templateUrl: './userinfo.component.html',
  styleUrls: ['./userinfo.component.css']
})
export class UserinfoComponent implements OnInit {
  private userservice: UserService;
  public actualuser: User;


  constructor(u_service: UserService) {
    this.actualuser = new User();
    this.userservice = u_service;
  }

  ngOnInit() {
    this.userservice.obsUser.subscribe(
      (user: User) => {
        this.actualuser = user;
      }
    );
  }

}
