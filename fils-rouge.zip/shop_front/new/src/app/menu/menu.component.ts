import { Component, OnInit } from '@angular/core';
import { UserService } from '../service/user.service';
import { User } from '../bean/User';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})

export class MenuComponent implements OnInit {
  public isAdmin: boolean;
  private _userService:UserService;

  constructor(p_service:UserService) {
    this.isAdmin = ( p_service.getCurrentUser() == null ) ? false : p_service.getCurrentUser().admin;
    this._userService = p_service;
  }

  ngOnInit() {
    this._userService.obsUser.subscribe(
      (user:User) => {
        this.isAdmin = user.admin;
    }
  );
  }
}
