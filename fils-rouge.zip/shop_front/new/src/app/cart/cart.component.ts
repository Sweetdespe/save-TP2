import { Component, OnInit } from '@angular/core';
import { CartService } from '../service/cart.service';
import { ProductService } from '../service/product.service';
import { Product } from '../bean/product';
import { Cart } from '../bean/cart';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  private service: CartService;
  private serviceproduct: ProductService
  public allcart: Array<Cart>;
  public allcartproducts: Array<Product>;
  public cartItem: Product;
  public allinOne: Array<object>;

  constructor(p_service: CartService, p_serviceproduct: ProductService) {
    this.service = p_service;
    this.allcart = new Array<Cart>();
    this.allcartproducts = new Array<Product>();
    this.allinOne = new Array<object>();
    this.serviceproduct = p_serviceproduct;

  }

  public displayCartItems(p_product: Cart): Product {

    let index: number = this.allcart.indexOf(p_product);
    let i: number = 0;
    let max: number = this.allcartproducts.length;
    for (i = 0; i < max; i++) {
      if (this.allcartproducts[i].id == this.allcart[index].productID) {
        return this.allcartproducts[i];
      }
    }
  }

  public updateQuantity(p_product: Cart): void {
    this.service.updateItemQtyOnCart(p_product).then(() => { this.ngOnInit(); }

    );
  }

  public remove(p_productID: number): void {
    this.service.removeProductFromCart(p_productID).then(() => { this.ngOnInit(); });
  }

  ngOnInit() {

    this.service.getCarts().then(

      (carts: Array<Cart>) => {
        this.allcart = carts;

        this.serviceproduct.getProducts().then(
          (products: Product[]) => {
            this.allcartproducts = products;
          }
        );
      }

    ).catch((error: any) => {
      console.log(error)
    });

  }
}
