import { Component, OnInit } from '@angular/core';
import { LoginService } from '../service/login.service';
import { UserService } from '../service/user.service';

import { User } from '../bean/user';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  private loginService: LoginService;
  private userService: UserService;
  users: User[];
  public isAdmin: boolean;
  public isVendeur: boolean;
  public isAuth: boolean;

  constructor(l_service: LoginService, u_service: UserService) {
    this.userService = u_service;
    this.loginService = l_service;
    this.isAdmin = false;
    this.isAuth = false;
    this.isVendeur = false;
    
  }
  public isadmin() {
    if (sessionStorage.getItem('roleuser') === 'ADMINISTRATEUR') {
      this.isAdmin = true;
    }
  }
  public isVENDEUR() {
    if (sessionStorage.getItem('roleuser') === 'UTILISATEUR') {
      this.isVendeur = true;
    }
  }

  ngOnInit() {
    this.userService.getUsers().subscribe(data => {
      this.users = data;
    });
    this.loginService.VerifConnexion();
    this.isadmin();
    this.isVENDEUR();
    this.isAuth = this.loginService.isAuthenticated();
    console.log('isAuth : ', this.isAuth);
    console.log('isAdmin : ', this.isAdmin);
    console.log('isVendeur : ', this.isVendeur);
  }
}
