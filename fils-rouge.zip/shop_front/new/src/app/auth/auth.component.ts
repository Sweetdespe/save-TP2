import { Component, OnInit } from '@angular/core';
import { User } from '../bean/User';
import { UserService } from '../service/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css']
})
export class AuthComponent implements OnInit {
  public user: User;
  public current_user: User;
  public users: Array<User>;
  private user_service: UserService;


  //  ***** Constructor *****/
  constructor(P_user_servise: UserService, public route: Router) {
    this.user_service = P_user_servise;
    this.user = new User();
    this.current_user = new User();
    this.users = new Array<User>();

  }
  // ***** Suppression par ID ******/
  public DelUser(p_id: number): void {
    this.user_service.removeUser(p_id).subscribe(() => {
      this.ngOnInit()
    });
  }
  // ***** creation utilisateur *****/
  public PostUser(p_name: string, p_email: string, p_password: string): void {
    this.user_service.addUser(p_name, p_email, p_password).subscribe(() => {
      this.ngOnInit();
    }

    );
  }
  // ****** Authentation *****/
  public LoginUser(p_email: string, p_password: string): void {
    this.user_service.auth(p_email, p_password).subscribe(() => {
      this.route.navigate(['home']);
      this.user[1] = this.user_service.getUsers();
      this.current_user = this.user;
      console.log(this.current_user.email);
    }
    );
  }


  ngOnInit() {
  }

}


