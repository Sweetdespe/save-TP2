import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { MenuComponent } from './menu/menu.component';
import { CatalogComponent } from './catalog/catalog.component';
import { FooterComponent } from './footer/footer.component';
import { ProductThumbComponent } from './product-thumb/product-thumb.component';

import { AlphaPipe } from './pipe/alpha.pipe';
import { PricePipe } from './pipe/price.pipe';
import { HomeComponent } from './home/home.component';
import { ProductService } from './service/product.service';
import { CartService } from './service/cart.service';
import { CartComponent } from './cart/cart.component';
import { UserService } from './service/user.service';
import { AdminProductComponent } from './admin-product/admin-product.component';

import { ProductDetailComponent } from './product-detail/product-detail.component';
import { AuthComponent } from './auth/auth.component';
import { SubscribeComponent } from './subscribe/subscribe.component';
import { UserinfoComponent } from './userinfo/userinfo.component';
import { AdminCartComponent } from './admin-cart/admin-cart.component';
import { AdminUserComponent } from './admin-user/admin-user.component';
import { AdminGuard } from './admin.guard';
import { UserComponent } from './user/user.component';
import { Version3Component } from './version3/version3.component';
import { LoginService } from './service/login.service';
import { CommonModule } from '@angular/common';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    MenuComponent,
    CatalogComponent,
    FooterComponent,
    ProductThumbComponent,
    AlphaPipe,
    PricePipe,
    HomeComponent,
    CartComponent,
    AdminProductComponent,
    AuthComponent,
    SubscribeComponent,
    UserinfoComponent,
    AdminCartComponent,
    ProductDetailComponent,
    AdminUserComponent,
    UserComponent,
    Version3Component

  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    CommonModule,
    RouterModule.forRoot(
      [
        {
          path: "home",
          component: HomeComponent,
          pathMatch: 'full'
        },
        {
          path: "catalog",
          component: CatalogComponent,
          pathMatch: 'full'
        },
        {
          path: "detail",
          component: ProductDetailComponent,
          pathMatch: 'full'
        },
        {
          path: "version3",
          component: Version3Component,
          pathMatch: 'full'
        },
        {
          path: "login",
          component: AuthComponent,
          pathMatch: 'full'
        },
        {
          path: "subscribe",
          component: SubscribeComponent,
          pathMatch: 'full'
        },
        {
          path: "me",
          component: UserinfoComponent,
          pathMatch: 'full',
          canActivate: [AdminGuard]             // authenticated user
        },
        {
          path: "cart",
          component: CartComponent,
          pathMatch: 'full',
          canActivate: [AdminGuard]             // authenticated user
        },
        {
          path: "admin/carts",
          component: AdminCartComponent,
          pathMatch: 'full',
          canActivate: [AdminGuard]             // authenticated Admin
        },
        {
          path: "admin/catalog",
          component: AdminProductComponent,
          pathMatch: 'full',
          canActivate: [AdminGuard]             // authenticated Admin
        },
        {
          path: "users/carts",
          component: AdminUserComponent,
          pathMatch: 'full',
          canActivate: [AdminGuard]             // authenticated Admin
        }
      ],
      {
        useHash: true
      }
    )
  ],
  providers: [ProductService, CartService, UserService, AdminGuard, LoginService],
  bootstrap: [
    AppComponent
  ]
})
export class AppModule { }
