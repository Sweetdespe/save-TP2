export class Cart {
    public id:number;
    public productID:number;
    public quantity:number;
}