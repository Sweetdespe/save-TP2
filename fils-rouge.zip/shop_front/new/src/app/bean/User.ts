export class User{
    public id:number;
    public name:string;
    public email:string;
    public apikey:string;
    public password:string;
    public admin:boolean;
}