import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { UserService } from './service/user.service';

@Injectable({
  providedIn: 'root'
})
export class AdminGuard implements CanActivate {


  private _userService: UserService;

  constructor(p_service: UserService) {
    this._userService = p_service;
  }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {

    if (
      this._userService.getCurrentUser() != null &&
      this._userService.getCurrentUser().admin == true
    ) {
      return true;
    }
    else {
      return false;
    }
  }
}
