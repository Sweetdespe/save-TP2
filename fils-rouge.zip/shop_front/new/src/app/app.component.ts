import { Component } from '@angular/core';
import { UserService } from './service/user.service';
import { User } from './bean/User';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(p_service: UserService) {

    p_service.auth("toto@toto.com", "azerty").subscribe(
      () => {
        p_service.removeUser(3).subscribe(
          (success: boolean) => {
            if (success) {
              alert("utilisateur supprimé !");
            }
          }
        )
      }
    );

  }
}
