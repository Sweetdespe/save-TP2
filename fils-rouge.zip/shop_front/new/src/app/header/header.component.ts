import { Component, OnInit } from '@angular/core';
import { UserService } from '../service/user.service';
import { User } from '../bean/User';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  public show: boolean = false;
  private ServiceUtilisateur: UserService;
  private current_user: User;
  public user: User;
  public title = "email";
  public user_name = "";
  
  constructor(P_user_servise: UserService) {
    this.show = false;
    this.ServiceUtilisateur = P_user_servise;
   
  }



  public VoirUtilisateur(): boolean {

    if (this.current_user != null) {
      this.show = true;
      this.user[1] = this.ServiceUtilisateur.getUsers();
      this.current_user = this.user;
      console.log(this.current_user.email);
      this.user_name = this.current_user.name;
      return this.show
    }  
    return this.show;
  }

  ngOnInit() {
    this.ServiceUtilisateur.obsUser.subscribe(
      () => {
//        this.current_user = p_user;
        this.VoirUtilisateur();
        console.log("is there somebady");
      }
    );
    
  }

}
