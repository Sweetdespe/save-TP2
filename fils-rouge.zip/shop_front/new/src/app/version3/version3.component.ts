import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-version3',
  templateUrl: './version3.component.html',
  styleUrls: ['./version3.component.css']
})
export class Version3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
