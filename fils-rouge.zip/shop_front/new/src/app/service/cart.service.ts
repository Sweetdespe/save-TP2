import { Injectable } from '@angular/core';
import { Product } from '../bean/product';
import { Cart } from '../bean/cart';
import { Http, Response, URLSearchParams, RequestOptions, Headers } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { environment } from '../../environments/environment';
import { ProductService } from './product.service';
@Injectable({
  providedIn: 'root'
})
export class CartService {

  private service: Http;
  private productService: ProductService;

  constructor(p_service: Http, p_productService: ProductService) {
    this.service = p_service;
    this.productService = p_productService;
  }


  public getCarts(): Promise<Array<Cart>> {

    const promise: Promise<Array<Cart>> = this.service.get(
      environment.getCartUrl
    ).toPromise()
      .then(
        (rep: Response): Array<Cart> => {


          return rep.json() as Array<Cart>;
        }
      ).catch((error: any): Promise<any> => {
        return Promise.reject(error);
      });

    return promise;

  }



  public postProductOnCart(p_productID: number): Promise<Object> {
    let body: URLSearchParams = new URLSearchParams();
    let header: Headers = new Headers(
      { "Content-Type": "application/x-www-form-urlencoded" }
    );
    let options: RequestOptions = new RequestOptions();
    body.set("productID", p_productID.toString());

    options.headers = header;

    const promise: Promise<object> = this.service.post(
      environment.postCartUrl,
      body,
      options
    ).toPromise()
      .then(
        (rep: Response): Array<Product> => {

          return rep.json();
        }
      ).catch((error: any): Promise<any> => {
        return Promise.reject(error);
      });

    return promise;

  }

  public removeProductFromCart(p_productID: number): Promise<Object> {

    let options: RequestOptions = new RequestOptions();
    options.params = new URLSearchParams();


    options.params.set("p_productID", p_productID.toString());
    options.params.set("api", "azerty123");

    const promise: Promise<object> = this.service.delete(
      environment.delCartUrl, options

    ).toPromise()
      .then(
        (rep: Response): Array<Product> => {


          return rep.json();
        }
      ).catch((error: any): Promise<any> => {
        return Promise.reject(error);
      });

    return promise;

  }


  public updateItemQtyOnCart(p_product: Cart): Promise<Object> {
    let body: URLSearchParams = new URLSearchParams();
    let header: Headers = new Headers(
      {
        "Content-Type": "application/x-www-form-urlencoded"

      }
    );
    let options: RequestOptions = new RequestOptions();


    options.params = new URLSearchParams();

    options.params.set("id", p_product.id.toString());
    options.params.set("api", "azerty123");
    options.params.set("productID", p_product.productID.toString());
    options.params.set("quantity", p_product.quantity.toString());


    options.headers = header;

    const promise: Promise<object> = this.service.put(
      environment.updateCartUrl,
      body,
      options
    ).toPromise()
      .then(
        (rep: Response): Array<Cart> => {


          return rep.json();
        }
      ).catch((error: any): Promise<any> => {
        return Promise.reject(error);
      });

    return promise;
  }


}
