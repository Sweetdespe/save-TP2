import { Injectable } from '@angular/core';
import { Router } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class LoginService {
  public role: string;
  constructor(
    private _router: Router
  ) { }


  VerifConnexion() {
    if (
      !sessionStorage.getItem('apikey') ||
      sessionStorage.getItem('apikey') === null
    ) {
      this._router.navigate(['login']);
    }
  }

  isAuthenticated() {
    return (
      sessionStorage.getItem('apikey') &&
      sessionStorage.getItem('apikey') !== null
    );
  }


}
