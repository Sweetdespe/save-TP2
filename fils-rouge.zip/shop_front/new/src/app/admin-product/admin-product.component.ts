import { Component, OnInit } from '@angular/core';
import { Product } from '../bean/product';
import { ProductService } from '../service/product.service';
import { CartService } from '../service/cart.service';
import { Cart } from '../bean/cart';

@Component({
  selector: 'app-admin-product',
  templateUrl: './admin-product.component.html',
  styleUrls: ['./admin-product.component.css']
})
export class AdminProductComponent implements OnInit {

  public product: Product;
  public current: Product;
  public catalog: Product[];
  private service: ProductService;
  private servicecart: CartService;
  public show: boolean;
  public cartItem: Cart[];
  public bool: boolean;

  constructor(p_service: ProductService, p_servicecart: CartService) {
    this.product = new Product();
    this.service = p_service;
    this.catalog = new Array<Product>();
    this.show = false;
    this.current = new Product();
    this.servicecart = p_servicecart;
    this.cartItem = new Array<Cart>();
    this.bool = false;
  }


  public togglediv(p_product: Product): void {
    this.show = !this.show;
    this.current = p_product
  }


  public postProductHandler(): void {
    this.service.postProduct(this.product).then(
      () => { this.ngOnInit(); window.location.reload(); }
    );
  }


  public updateProductHandler(p_product: Product): void {
    this.service.updateProduct(p_product).then(() => { this.ngOnInit(); }
    );

  }


  public getCartProductByproductID(p_productId: number): boolean {

    let max: number = this.cartItem.length;
    let i: number = 0;

    for (i = 0; i < max; i++) {
      if (this.cartItem[i].productID == p_productId) {
        return this.bool = true;
      }
    }
  }


  public delProductHandler(p_product: Product): void {
    this.service.removeProduct(p_product).then(
      () => {
        this.getCartProductByproductID(p_product.id);
        if (this.bool == true) {
          this.servicecart.removeProductFromCart(p_product.id);
        }
        this.ngOnInit();
      }
    );
  }

  ngOnInit() {
    this.service.getProducts().then(
      (tab: Product[]) => {
        this.catalog = tab;

        this.servicecart.getCarts().then(

          (table: Cart[]) => {
            this.cartItem = table;
          }
        );
      });
  }
}
