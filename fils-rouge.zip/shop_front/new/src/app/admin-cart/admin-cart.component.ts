import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-cart',
  templateUrl: './admin-cart.component.html',
  styleUrls: ['./admin-cart.component.css']
})
export class AdminCartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
